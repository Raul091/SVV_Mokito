package org.loose.vvs.seleniumtest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.loose.vvs.seleniumtest.services.GradesService;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.junit.jupiter.api.extension.ExtendWith;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.*;
import java.util.function.Supplier;

@ExtendWith(MockitoExtension.class)
class GradeServiceTest {
     List<Double> grades = new ArrayList<Double>();
        grades.add(9);
        grades.add(9);

     private GradesService gradeService;

     @BeforeEach void setUp(){
         gradeService = new GradesService();
     }

     @Test
    void testcalculateMeanFromThreeMinGrades(){
        assertEquals(9, gradesService.calculateMeanFromThreeMinGrades(grades));
     }
}

@Test
void testcalculateMeanFromThreeMinGradeswithMock() {
    gradeService.
}
