package org.loose.vvs.seleniumtest.exceptions;

public class InvalidGradeCountException extends RuntimeException {
}
