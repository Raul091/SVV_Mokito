package org.loose.vvs.seleniumtest.exceptions;

public class TooManyNumbersException extends RuntimeException {
}
