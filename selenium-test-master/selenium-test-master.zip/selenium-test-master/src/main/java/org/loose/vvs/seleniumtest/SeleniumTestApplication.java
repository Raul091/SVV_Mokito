package org.loose.vvs.seleniumtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeleniumTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(SeleniumTestApplication.class, args);
    }

}
