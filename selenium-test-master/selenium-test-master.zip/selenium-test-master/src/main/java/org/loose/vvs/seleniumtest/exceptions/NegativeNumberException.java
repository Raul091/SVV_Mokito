package org.loose.vvs.seleniumtest.exceptions;

public class NegativeNumberException extends RuntimeException {
}
