package org.loose.vvs.seleniumtest.exceptions;

public class NullListException extends RuntimeException {
}
