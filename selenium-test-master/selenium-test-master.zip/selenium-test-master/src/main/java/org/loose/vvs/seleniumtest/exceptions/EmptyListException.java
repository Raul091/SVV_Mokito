package org.loose.vvs.seleniumtest.exceptions;

public class EmptyListException extends RuntimeException {
}
